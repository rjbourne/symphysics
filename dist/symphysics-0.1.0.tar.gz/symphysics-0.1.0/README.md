*last updated 09/06/2020*

# Symphysics
The symphysics library for creating physics simulations using python and sympy

Repository: https://github.com/rjbourne/symphysics

Find the wiki at: https://github.com/rjbourne/symphysics/wiki

Download using
```cmd
pip install symphysics
```

The symphysics library contains the following tools

 - [SystemL](https://github.com/rjbourne/symphysics/wiki/SystemL)
 - [Animate](https://github.com/rjbourne/symphysics/wiki/Animate)